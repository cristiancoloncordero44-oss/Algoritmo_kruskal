import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    private static final String LINEA = "+-------+-----------------+-------+-----------+-----------+";

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        boolean salir = false;

        mostrarBanner();

        while (!salir) {
            mostrarMenu();
            int opcion = leerEntero(teclado, "Elige una opcion: ");
            switch (opcion) {
                case 1:
                    resolver(Grafo.ejemplo(), true);
                    break;
                case 2:
                    resolver(crearGrafoManual(teclado), true);
                    break;
                case 3:
                    int n = leerEntero(teclado, "Cantidad de vertices (2-26): ");
                    if (n < 2 || n > 26) {
                        System.out.println("Valor fuera de rango.");
                        break;
                    }
                    int extras = leerEntero(teclado, "Aristas adicionales: ");
                    resolver(Grafo.aleatorio(n, Math.max(extras, 0), System.nanoTime()), true);
                    break;
                case 0:
                    salir = true;
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        }

        System.out.println();
        System.out.println("Hasta pronto.");
        teclado.close();
    }

    private static void mostrarBanner() {
        System.out.println("=============================================");
        System.out.println("   ALGORITMO DE KRUSKAL - ARBOL MINIMO");
        System.out.println("   Andres Vergara  |  Cristian Colon");
        System.out.println("=============================================");
    }

    private static void mostrarMenu() {
        System.out.println();
        System.out.println("  [1] Ejecutar grafo de ejemplo");
        System.out.println("  [2] Ingresar mi propio grafo");
        System.out.println("  [3] Generar grafo aleatorio");
        System.out.println("  [0] Salir");
        System.out.println();
    }

    private static Grafo crearGrafoManual(Scanner teclado) {
        while (true) {
            try {
                int n = leerEntero(teclado, "Cantidad de vertices (2-26): ");
                if (n < 2 || n > 26) {
                    System.out.println("Debe estar entre 2 y 26.");
                    continue;
                }
                int m = leerEntero(teclado, "Cantidad de aristas: ");
                Grafo grafo = new Grafo(n);
                System.out.println("Escribe cada arista como: origen destino peso (letras A, B, C...)");
                for (int i = 1; i <= m; i++) {
                    System.out.print("Arista " + i + ": ");
                    String a = teclado.next().trim().toUpperCase();
                    String b = teclado.next().trim().toUpperCase();
                    int peso = teclado.nextInt();
                    grafo.agregarArista(a.charAt(0) - 'A', b.charAt(0) - 'A', peso);
                }
                return grafo;
            } catch (IllegalArgumentException | InputMismatchException e) {
                System.out.println("Dato invalido, intentalo de nuevo desde el inicio.");
                if (e instanceof InputMismatchException) {
                    teclado.nextLine();
                }
            }
        }
    }

    private static void resolver(Grafo grafo, boolean detalle) {
        System.out.println();
        System.out.println("Grafo con " + grafo.getVertices() + " vertices y " + grafo.getAristas().size() + " aristas");
        System.out.println();

        ResultadoKruskal resultado = Kruskal.ejecutar(grafo);

        if (detalle) {
            imprimirPasos(resultado.getPasos());
        }

        System.out.println();
        System.out.println(resultado.isConexo() ? "ARBOL DE EXPANSION MINIMA" : "BOSQUE DE EXPANSION MINIMA (grafo no conexo)");
        for (Arista a : resultado.getArbol()) {
            System.out.println("   " + etiqueta(a.getOrigen()) + " --(" + a.getPeso() + ")-- " + etiqueta(a.getDestino()));
        }
        System.out.println();
        System.out.println("Aristas elegidas: " + resultado.getArbol().size());
        System.out.println("Peso total minimo: " + resultado.getPesoTotal());
    }

    private static void imprimirPasos(List<Paso> pasos) {
        System.out.println(LINEA);
        System.out.println(String.format("| %-5s | %-15s | %-5s | %-9s | %-9s |", "Paso", "Arista", "Peso", "Decision", "Acumulado"));
        System.out.println(LINEA);
        for (Paso p : pasos) {
            Arista a = p.getArista();
            String nombre = etiqueta(a.getOrigen()) + " - " + etiqueta(a.getDestino());
            String decision = p.isAceptada() ? "ACEPTADA" : "RECHAZADA";
            System.out.println(String.format("| %-5d | %-15s | %-5d | %-9s | %-9d |", p.getNumero(), nombre, a.getPeso(), decision, p.getPesoAcumulado()));
        }
        System.out.println(LINEA);
    }

    private static String etiqueta(int vertice) {
        return String.valueOf((char) ('A' + vertice));
    }

    private static int leerEntero(Scanner teclado, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            if (teclado.hasNextInt()) {
                return teclado.nextInt();
            }
            System.out.println("Escribe un numero entero.");
            teclado.next();
        }
    }
}

class Arista implements Comparable<Arista> {
    private final int origen;
    private final int destino;
    private final int peso;

    public Arista(int origen, int destino, int peso) {
        this.origen = origen;
        this.destino = destino;
        this.peso = peso;
    }

    public int getOrigen() {
        return origen;
    }

    public int getDestino() {
        return destino;
    }

    public int getPeso() {
        return peso;
    }

    @Override
    public int compareTo(Arista otra) {
        int comparacion = Integer.compare(this.peso, otra.peso);
        if (comparacion != 0) {
            return comparacion;
        }
        comparacion = Integer.compare(this.origen, otra.origen);
        if (comparacion != 0) {
            return comparacion;
        }
        return Integer.compare(this.destino, otra.destino);
    }

    @Override
    public String toString() {
        return origen + " - " + destino + " (" + peso + ")";
    }
}

class ConjuntoDisjunto {
    private final int[] padre;
    private final int[] rango;
    private int componentes;

    public ConjuntoDisjunto(int n) {
        padre = new int[n];
        rango = new int[n];
        componentes = n;
        for (int i = 0; i < n; i++) {
            padre[i] = i;
        }
    }

    public int encontrar(int x) {
        if (padre[x] != x) {
            padre[x] = encontrar(padre[x]);
        }
        return padre[x];
    }

    public boolean unir(int a, int b) {
        int raizA = encontrar(a);
        int raizB = encontrar(b);
        if (raizA == raizB) {
            return false;
        }
        if (rango[raizA] < rango[raizB]) {
            padre[raizA] = raizB;
        } else if (rango[raizA] > rango[raizB]) {
            padre[raizB] = raizA;
        } else {
            padre[raizB] = raizA;
            rango[raizA]++;
        }
        componentes--;
        return true;
    }

    public int getComponentes() {
        return componentes;
    }
}

class Grafo {
    private final int vertices;
    private final List<Arista> aristas = new ArrayList<>();

    public Grafo(int vertices) {
        if (vertices < 1) {
            throw new IllegalArgumentException("El grafo necesita al menos un vertice");
        }
        this.vertices = vertices;
    }

    public void agregarArista(int origen, int destino, int peso) {
        if (origen < 0 || origen >= vertices || destino < 0 || destino >= vertices) {
            throw new IllegalArgumentException("Vertice fuera de rango: " + origen + " - " + destino);
        }
        if (origen == destino) {
            throw new IllegalArgumentException("No se permiten lazos");
        }
        if (peso < 0) {
            throw new IllegalArgumentException("El peso no puede ser negativo");
        }
        aristas.add(new Arista(origen, destino, peso));
    }

    public int getVertices() {
        return vertices;
    }

    public List<Arista> getAristas() {
        return Collections.unmodifiableList(aristas);
    }

    public static Grafo ejemplo() {
        Grafo g = new Grafo(6);
        g.agregarArista(0, 1, 4);
        g.agregarArista(0, 2, 2);
        g.agregarArista(1, 2, 1);
        g.agregarArista(1, 3, 5);
        g.agregarArista(2, 3, 8);
        g.agregarArista(2, 4, 10);
        g.agregarArista(3, 4, 2);
        g.agregarArista(3, 5, 6);
        g.agregarArista(4, 5, 3);
        return g;
    }

    public static Grafo aleatorio(int vertices, int extras, long semilla) {
        Random azar = new Random(semilla);
        Grafo g = new Grafo(vertices);
        for (int i = 1; i < vertices; i++) {
            g.agregarArista(azar.nextInt(i), i, 1 + azar.nextInt(20));
        }
        int intentos = 0;
        int agregadas = 0;
        while (agregadas < extras && intentos < extras * 20) {
            intentos++;
            int a = azar.nextInt(vertices);
            int b = azar.nextInt(vertices);
            if (a != b) {
                g.agregarArista(a, b, 1 + azar.nextInt(20));
                agregadas++;
            }
        }
        return g;
    }
}

class Kruskal {

    public static ResultadoKruskal ejecutar(Grafo grafo) {
        List<Arista> ordenadas = new ArrayList<>(grafo.getAristas());
        Collections.sort(ordenadas);

        ConjuntoDisjunto conjuntos = new ConjuntoDisjunto(grafo.getVertices());
        List<Arista> arbol = new ArrayList<>();
        List<Paso> pasos = new ArrayList<>();
        int pesoTotal = 0;
        int numeroPaso = 0;

        for (Arista arista : ordenadas) {
            numeroPaso++;
            boolean aceptada = conjuntos.unir(arista.getOrigen(), arista.getDestino());
            if (aceptada) {
                arbol.add(arista);
                pesoTotal += arista.getPeso();
            }
            pasos.add(new Paso(numeroPaso, arista, aceptada, pesoTotal));
            if (arbol.size() == grafo.getVertices() - 1) {
                break;
            }
        }

        boolean conexo = conjuntos.getComponentes() == 1;
        return new ResultadoKruskal(arbol, pasos, pesoTotal, conexo);
    }
}

class Paso {
    private final int numero;
    private final Arista arista;
    private final boolean aceptada;
    private final int pesoAcumulado;

    public Paso(int numero, Arista arista, boolean aceptada, int pesoAcumulado) {
        this.numero = numero;
        this.arista = arista;
        this.aceptada = aceptada;
        this.pesoAcumulado = pesoAcumulado;
    }

    public int getNumero() {
        return numero;
    }

    public Arista getArista() {
        return arista;
    }

    public boolean isAceptada() {
        return aceptada;
    }

    public int getPesoAcumulado() {
        return pesoAcumulado;
    }
}

class ResultadoKruskal {
    private final List<Arista> arbol;
    private final List<Paso> pasos;
    private final int pesoTotal;
    private final boolean conexo;

    public ResultadoKruskal(List<Arista> arbol, List<Paso> pasos, int pesoTotal, boolean conexo) {
        this.arbol = arbol;
        this.pasos = pasos;
        this.pesoTotal = pesoTotal;
        this.conexo = conexo;
    }

    public List<Arista> getArbol() {
        return arbol;
    }

    public List<Paso> getPasos() {
        return pasos;
    }

    public int getPesoTotal() {
        return pesoTotal;
    }

    public boolean isConexo() {
        return conexo;
    }
}
